$('.mask').mask('+7 (999) 999-99-99');
/*---------------------------------------------------end*/
$("form").submit(function () {
  $('.submit').attr('disabled', 'disabled');
  $.ajax({
    type: "POST",
    method: 'POST',
    url: "smart.php",
    data: $(this).serialize()
  }).done(function () {
    $(this).find('input').val("");
    $('.modal').fadeOut();
    $('form').trigger('reset');
    $('.submit').removeAttr('disabled');
    alert('Отправлено!')
    // setTimeout(function(){ 
    //     $(document.body).removeClass('is-open-modal');
    //     $('.modal').fadeOut();
    //  }, 3000);
  });
  return false;
});
/*---------------------------------------------------end*/

$(function () {
  function showModal(id) {
    $(id).fadeIn();
  }
  function hideModals() {
    $(document.body).removeClass('is-open-modal');
    $('.modal').fadeOut();
  };


  $('.open-modal').on('click', function () {
    showModal('#modal_1');
  });
  $('.modal_2').on('click', function () {
    showModal('#modal_2');
  });

  $('.modalClose').on('click', function () {
    hideModals();
  });
  $(document).on('click', function (e) {
    if (!(
      ($(e.target).parents('.modal-content').length)
      || ($(e.target).hasClass('modal-content'))
      || ($(e.target).hasClass('open-modal'))
      || ($(e.target).hasClass('modal_2'))
    )
    ) {
      hideModals();
    }
  });

});
/*---------------------------------------------------end*/

$('.go_to').click(function () {
  var scroll_el = $(this).attr('href');
  if ($(scroll_el).length != 0) {
    $('html, body').animate({ scrollTop: $(scroll_el).offset().top }, 1000);
  }
  return false;
});
